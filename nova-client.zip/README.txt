NOVA CLIENT - Fabric 26.1.2 (Java 25) - singleplayer PvP practice client
=======================================================================
Layout (matches the official fabric-example-mod 26.1.2 branch):
  build.gradle / gradle.properties / settings.gradle
  src/client/java/dev/nova/*.java      <- all mod code (client-only)
  src/main/resources/fabric.mod.json
  .github/workflows/build.yml          <- GitHub Actions build (uploads the jar)

BUILD LOCALLY
  1. Install JDK 25 and Gradle 9.4+  (or copy gradlew, gradlew.bat and gradle/wrapper/gradle-wrapper.jar
     from FabricMC/fabric-example-mod, branch 26.1.2, into this folder).
  2. gradle build          (or ./gradlew build)   -> jar in build/libs/nova-client-1.0.0.jar
  3. gradle runClient      -> launches the game in dev; make a singleplayer world; press RIGHT SHIFT.

BUILD ON GITHUB
  Push this folder to a repo -> Actions tab -> "build" -> download the "nova-client" artifact.

INSTALL
  Put build/libs/nova-client-1.0.0.jar in .minecraft/mods with Fabric Loader 0.19.3+ and Fabric API for 26.1.2.

NOTES
  - Singleplayer only: every combat module shuts off outside a singleplayer world.
  - Right-click a module in the GUI to see its settings. Every module has a Tick Delay slider unless it has its own delays.
  - SafeAnchor/AnchorAura: glowstone + anchors in HOTBAR (not offhand). Overworld only.
  - Offhand and AutoTotem both swap the offhand - use one at a time.
  - Placement modules need obsidian in the hotbar. AutoGap/AutoXP/AutoArmor only use hotbar slots.
  - HoverTotem: enable it, open inventory (E), hover a totem.
