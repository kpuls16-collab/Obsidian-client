package dev.nova;

import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        COMBAT("Combat"), CRYSTAL("Crystal PvP"), MOVEMENT("Movement"), RENDER("Render");
        public final String label;
        Category(String l) { label = l; }
    }

    public final String name, desc;
    public final Category cat;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();
    protected final Minecraft mc = Minecraft.getInstance();

    /** Extra ticks to wait between runs (every module has this unless it has its own delays). 20 ticks = 1 second. */
    protected final Setting tickDelay;
    private int tdTimer;
    /** false = module may stay on outside singleplayer (HUD-type modules only) */
    protected boolean spOnly = true;
    public boolean spOnly() { return spOnly; }

    protected Module(String name, String desc, Category cat) {
        this.name = name; this.desc = desc; this.cat = cat;
        tickDelay = num("Tick Delay", 0, 0, 20);
    }

    /** modules that manage their own delays / run continuously drop the generic Tick Delay slider */
    protected void noDelay() { settings.remove(tickDelay); tickDelay.value = 0; }

    protected Setting num(String n, double v, double min, double max) {
        Setting s = new Setting(n, v, min, max); settings.add(s); return s;
    }
    protected Setting num(String n, double v, double min, double max, double step) {
        Setting s = new Setting(n, v, min, max, step); settings.add(s); return s;
    }
    protected Setting bool(String n, boolean v) {
        Setting s = new Setting(n, v); settings.add(s); return s;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean e) {
        if (e == enabled) return;
        if (e && spOnly && !Nova.singleplayer()) { Nova.msg("Nova only works in singleplayer"); return; }
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    /** called by Nova every client tick; applies the Tick Delay setting */
    public final void tick() {
        if (tdTimer++ < tickDelay.i()) return;
        tdTimer = 0;
        onTick();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    /** return true to keep ticking while a GUI screen (e.g. inventory) is open */
    public boolean tickInScreen() { return false; }
}
