package dev.nova;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public class Modules {
    public static List<Module> all() {
        List<Module> l = new ArrayList<>(List.of(
            new KillAura(), new TriggerBot(), new AimAssist(), new AutoCrystal(), new AutoTotem(), new Surround(),
            new Sprint(), new Speed(), new Flight(),
            new Fullbright(), new ESP(), new HUD()));
        l.addAll(CrystalModules.all());
        return l;
    }

    // ───────────── COMBAT ─────────────
    public static class KillAura extends Module {
        Setting range = num("Range", 4.2, 2, 6), cool = num("Min Cooldown %", 95, 0, 100),
                hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true), low = bool("Lowest HP First", false),
                rotate = bool("Rotate", true), rotSpeed = num("Rotate Speed", 1, 0.1, 1), swing = bool("Swing", true);
        public KillAura() { super("KillAura", "Attacks the best target in range", Category.COMBAT); }
        @Override public void onTick() {
            var p = mc.player; LivingEntity t = Util.target(range.get(), hostile.on(), stands.on(), low.on());
            if (t == null) return;
            if (rotate.on()) Util.rotate(Util.aim(t), rotSpeed.get());
            if (p.getAttackStrengthScale(0.5f) * 100 >= cool.get()) {
                mc.gameMode.attack(p, t);
                if (swing.on()) p.swing(InteractionHand.MAIN_HAND);
            }
        }
    }

    public static class TriggerBot extends Module {
        Setting cool = num("Min Cooldown %", 95, 0, 100), hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true),
                crits = bool("Crits Only", false), swing = bool("Swing", true);
        public TriggerBot() { super("TriggerBot", "Hits whatever your crosshair is on", Category.COMBAT); }
        @Override public void onTick() {
            var p = mc.player;
            if (!(mc.crosshairPickEntity instanceof LivingEntity le) || !Util.valid(le, hostile.on(), stands.on())) return;
            if (p.getAttackStrengthScale(0.5f) * 100 < cool.get()) return;
            if (crits.on() && (p.onGround() || p.isInWater() || p.onClimbable() || p.getDeltaMovement().y >= 0)) return;
            mc.gameMode.attack(p, le);
            if (swing.on()) p.swing(InteractionHand.MAIN_HAND);
        }
    }

    public static class AimAssist extends Module {
        Setting range = num("Range", 6, 3, 10), speed = num("Smooth", 0.25, 0.05, 1, 0.05), fov = num("FOV", 90, 10, 180),
                vertical = bool("Vertical", true), onlyAtk = bool("Only While Attacking", false),
                hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true);
        public AimAssist() { super("AimAssist", "Smoothly pulls your aim to the nearest target", Category.COMBAT); }
        @Override public void onTick() {
            var p = mc.player;
            if (onlyAtk.on() && !mc.options.keyAttack.isDown()) return;
            LivingEntity t = Util.target(range.get(), hostile.on(), stands.on(), false); if (t == null) return;
            float[] a = Util.aim(t);
            if (Math.abs(Mth.wrapDegrees(a[0] - p.getYRot())) > fov.get() / 2) return;
            p.setYRot(p.getYRot() + Mth.wrapDegrees(a[0] - p.getYRot()) * (float) speed.get());
            if (vertical.on()) p.setXRot(p.getXRot() + Mth.wrapDegrees(a[1] - p.getXRot()) * (float) speed.get());
        }
    }

    // ───────────── CRYSTAL (core) ─────────────
    public static class AutoCrystal extends Module {
        Setting place = bool("Place", true), brk = bool("Break", true),
                placeRange = num("Place Range", 4.5, 2, 6), breakRange = num("Break Range", 4.5, 2, 6),
                targetRange = num("Target Range", 10, 3, 16), maxTargetDist = num("Max Target Dist", 6, 2, 10),
                minSelf = num("Min Self Dist", 2.5, 0, 6), placeDelay = num("Place Delay", 2, 0, 20),
                breakDelay = num("Break Delay", 1, 0, 20), minHealth = num("Min Health", 8, 0, 20),
                swap = bool("Auto Switch", true), swing = bool("Swing", true), bedrock = bool("Use Bedrock", true),
                rotate = bool("Rotate", false), hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true),
                low = bool("Lowest HP First", false);
        int pc, bc;
        public AutoCrystal() { super("AutoCrystal", "Places + breaks end crystals on obsidian near the target", Category.CRYSTAL); noDelay(); }

        @Override public void onTick() {
            var p = mc.player; var lvl = mc.level; pc++; bc++;
            if (brk.on() && bc >= breakDelay.i()) {
                for (Entity e : lvl.entitiesForRendering()) {
                    if (e instanceof EndCrystal && p.getEyePosition().distanceTo(e.position()) <= breakRange.get()) {
                        if (rotate.on()) Util.rotate(Util.aim(e), 1);
                        mc.gameMode.attack(p, e);
                        if (swing.on()) p.swing(InteractionHand.MAIN_HAND);
                        bc = 0; break;
                    }
                }
            }
            if (!place.on()) return;
            LivingEntity t = Util.target(targetRange.get(), hostile.on(), stands.on(), low.on());
            if (t == null || pc < placeDelay.i() || p.getHealth() <= minHealth.get()) return;
            InteractionHand hand = InteractionHand.MAIN_HAND;
            if (p.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
            else if (!p.getMainHandItem().is(Items.END_CRYSTAL)) {
                int s = Util.hotbar(Items.END_CRYSTAL);
                if (s < 0 || !swap.on()) return;
                p.getInventory().setSelectedSlot(s);
            }
            BlockPos best = null; double bd = 1e9; int r = (int) Math.ceil(placeRange.get()); BlockPos c = p.blockPosition();
            for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -3, -r), c.offset(r, 2, r))) {
                var st = lvl.getBlockState(pos);
                if (!st.is(Blocks.OBSIDIAN) && !(bedrock.on() && st.is(Blocks.BEDROCK))) continue;
                if (!lvl.getBlockState(pos.above()).isAir() || !lvl.getBlockState(pos.above(2)).isAir()) continue;
                Vec3 hit = Vec3.atCenterOf(pos).add(0, 0.5, 0);
                if (p.getEyePosition().distanceTo(hit) > placeRange.get()) continue;
                Vec3 cr = Vec3.atBottomCenterOf(pos.above());
                if (cr.distanceTo(p.position()) < minSelf.get()) continue;
                if (!lvl.getEntities((Entity) null, new AABB(pos.above())).isEmpty()) continue;
                double d = cr.distanceTo(t.position());
                if (d < bd && d <= maxTargetDist.get()) { bd = d; best = pos.immutable(); }
            }
            if (best != null) {
                if (rotate.on()) Util.rotate(Util.aimAt(Vec3.atCenterOf(best).add(0, 0.5, 0)), 1);
                mc.gameMode.useItemOn(p, hand, new BlockHitResult(Vec3.atCenterOf(best).add(0, 0.5, 0), Direction.UP, best, false));
                if (swing.on()) p.swing(hand);
                pc = 0;
            }
        }
    }

    public static class AutoTotem extends Module {
        Setting belowHp = num("Only Below HP", 20, 1, 20), absorb = bool("Count Absorption", true);
        public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand (from hotbar)", Category.CRYSTAL); }
        @Override public void onTick() {
            var p = mc.player;
            if (p.getHealth() + (absorb.on() ? p.getAbsorptionAmount() : 0) > belowHp.get()) return;
            Util.offhandSwap(Items.TOTEM_OF_UNDYING);
        }
    }

    public static class Surround extends Module {
        Setting perTick = num("Blocks/Tick", 2, 1, 4), tall = bool("Double Height", false),
                ground = bool("Only On Ground", true), autoOff = bool("Auto Disable", false);
        public Surround() { super("Surround", "Boxes your feet in with obsidian", Category.CRYSTAL); }
        @Override public void onTick() {
            var p = mc.player;
            if (ground.on() && !p.onGround()) return;
            BlockPos f = p.blockPosition(); int placed = 0, needed = 0;
            for (int layer = 0; layer < (tall.on() ? 2 : 1); layer++)
                for (Direction d : Direction.Plane.HORIZONTAL) {
                    BlockPos n = f.relative(d).above(layer);
                    if (!mc.level.getBlockState(n).canBeReplaced()) continue;
                    needed++;
                    if (placed < perTick.i() && Util.place(n, Items.OBSIDIAN, true)) placed++;
                }
            if (needed == 0 && autoOff.on()) { Nova.msg("Surround complete"); setEnabled(false); }
        }
    }

    // ───────────── MOVEMENT ─────────────
    public static class Sprint extends Module {
        Setting omni = bool("All Directions", false), sneak = bool("Not While Sneaking", true);
        public Sprint() { super("Sprint", "Always sprint while moving", Category.MOVEMENT); }
        @Override public void onTick() {
            var o = mc.options;
            if (sneak.on() && mc.player.isCrouching()) return;
            boolean move = o.keyUp.isDown() || (omni.on() && (o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown()));
            if (move) mc.player.setSprinting(true);
        }
    }

    public static class Speed extends Module {
        Setting mult = num("Speed", 1.4, 1, 3), ground = bool("Ground Only", true), jump = bool("Auto Jump", false),
                needSprint = bool("Only While Sprinting", false);
        public Speed() { super("Speed", "Faster movement", Category.MOVEMENT); }
        @Override public void onTick() {
            var p = mc.player; var o = mc.options;
            if (!(o.keyUp.isDown() || o.keyDown.isDown() || o.keyLeft.isDown() || o.keyRight.isDown())) return;
            if (needSprint.on() && !p.isSprinting()) return;
            if (jump.on() && p.onGround()) p.setDeltaMovement(p.getDeltaMovement().x, 0.42, p.getDeltaMovement().z);
            if (ground.on() && !p.onGround()) return;
            Vec3 v = p.getDeltaMovement(); double s = 0.2873 * mult.get();
            double yaw = Math.toRadians(p.getYRot()), fw = (o.keyUp.isDown() ? 1 : 0) - (o.keyDown.isDown() ? 1 : 0),
                   st = (o.keyLeft.isDown() ? 1 : 0) - (o.keyRight.isDown() ? 1 : 0);
            double len = Math.max(1, Math.sqrt(fw * fw + st * st));
            p.setDeltaMovement((-Math.sin(yaw) * fw + Math.cos(yaw) * st) / len * s, p.getDeltaMovement().y,
                               (Math.cos(yaw) * fw + Math.sin(yaw) * st) / len * s);
        }
    }

    public static class Flight extends Module {
        Setting speed = num("Fly Speed", 0.05, 0.02, 0.5, 0.01);
        public Flight() { super("Flight", "Creative-style flight", Category.MOVEMENT); noDelay(); }
        @Override public void onTick() {
            var a = mc.player.getAbilities(); a.mayfly = true; a.flying = true; a.setFlyingSpeed((float) speed.get());
        }
        @Override public void onDisable() {
            var p = mc.player; if (p == null) return;
            p.getAbilities().setFlyingSpeed(0.05f);
            if (p.isCreative() || p.isSpectator()) return;
            p.getAbilities().flying = false; p.getAbilities().mayfly = false;
        }
    }

    // ───────────── RENDER ─────────────
    public static class Fullbright extends Module {
        Setting amp = num("Amplifier", 0, 0, 3);
        public Fullbright() { super("Fullbright", "See in the dark", Category.RENDER); }
        @Override public void onTick() {
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, amp.i(), false, false));
        }
        @Override public void onDisable() { if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION); }
    }

    public static class ESP extends Module {
        Setting range = num("Range", 64, 8, 128), mobs = bool("Mobs", true), hostile = bool("Hostile Only", false),
                stands = bool("Armor Stands", true), crystals = bool("Crystals", true), items = bool("Items", false);
        public ESP() { super("ESP", "Glow outline on entities", Category.RENDER); }
        @Override public void onTick() {
            for (Entity e : mc.level.entitiesForRendering()) {
                boolean near = mc.player.distanceTo(e) <= range.get();
                if (e instanceof LivingEntity le && e != mc.player) e.setGlowingTag(near && mobs.on() && Util.valid(le, hostile.on(), stands.on()));
                else if (e instanceof EndCrystal) e.setGlowingTag(near && crystals.on());
                else if (e instanceof ItemEntity) e.setGlowingTag(near && items.on());
            }
        }
        @Override public void onDisable() {
            if (mc.level == null) return;
            for (Entity e : mc.level.entitiesForRendering())
                if (e != mc.player && (e instanceof LivingEntity || e instanceof EndCrystal || e instanceof ItemEntity)) e.setGlowingTag(false);
        }
    }

    public static class HUD extends Module {
        public Setting mark = bool("Watermark", true), list = bool("Module List", true), bg = bool("Background", true),
                left = bool("Left Side", false), hue = num("Accent Hue", 265, 0, 360), space = num("Spacing", 11, 9, 16);
        public HUD() { super("HUD", "Watermark + enabled module list", Category.RENDER); enabled = true; spOnly = false; noDelay(); }
    }
}
