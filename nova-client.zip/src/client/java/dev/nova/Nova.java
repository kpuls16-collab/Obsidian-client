package dev.nova;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Nova implements ClientModInitializer {
    public static final List<Module> MODULES = Modules.all();
    static KeyMapping openKey;

    public static boolean singleplayer() { return Minecraft.getInstance().getSingleplayerServer() != null; }

    public static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.gui.getChat().addMessage(Component.literal("§d[Nova]§r " + s));
    }

    @Override public void onInitializeClient() {
        var cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("nova", "main"));
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.nova.gui", InputConstants.KEY_RSHIFT, cat));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.level == null) return;
            while (openKey.consumeClick()) mc.setScreen(new ClickGui());
            boolean sp = singleplayer();
            for (Module m : MODULES) {
                if (!m.enabled) continue;
                if (!sp && m.spOnly()) { m.setEnabled(false); continue; }
                if (mc.screen == null || m.tickInScreen()) m.tick();
            }
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
            Identifier.fromNamespaceAndPath("nova", "hud"), Nova::renderHud);
    }

    static void renderHud(GuiGraphicsExtractor g, net.minecraft.client.DeltaTracker dt) {
        if (CrystalModules.PvPInfo.INSTANCE != null && CrystalModules.PvPInfo.INSTANCE.enabled) CrystalModules.PvPInfo.draw(g);
        Modules.HUD hud = (Modules.HUD) MODULES.stream().filter(m -> m instanceof Modules.HUD).findFirst().orElse(null);
        if (hud == null || !hud.enabled) return;
        Minecraft mc = Minecraft.getInstance();
        int accent = 0xFF000000 | Mth.hsvToRgb((float) (hud.hue.get() / 360.0), 0.45f, 1f);
        boolean left = hud.left.on();
        int y = 4;
        if (hud.mark.on()) { ClickGui.txt(g, "Nova", 6, 6, accent); if (left) y = 18; }
        if (!hud.list.on()) return;
        List<Module> on = new ArrayList<>();
        for (Module m : MODULES) if (m.enabled && !(m instanceof Modules.HUD) && !(m instanceof CrystalModules.PvPInfo)) on.add(m);
        on.sort(Comparator.comparingInt((Module m) -> mc.font.width(m.name)).reversed());
        int w = mc.getWindow().getGuiScaledWidth(), sp = hud.space.i();
        for (Module m : on) {
            int tw = mc.font.width(m.name);
            int x = left ? 4 : w - tw - 6;
            if (hud.bg.on()) g.fill(left ? 2 : x - 2, y - 1, left ? x + tw + 4 : w - 2, y + sp - 1, 0x90101014);
            g.fill(left ? 0 : w - 2, y - 1, left ? 2 : w, y + sp - 1, accent);
            ClickGui.txt(g, m.name, x, y + (sp - 9) / 2, 0xFFFFFFFF);
            y += sp;
        }
    }
}
