package dev.nova;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class ClickGui extends Screen {
    static final int BG = 0xF0141418, SIDE = 0xF00E0E12, ROW = 0xFF1C1C22, HOVER = 0xFF26262E,
                     ACCENT = 0xFFB388FF, TEXT = 0xFFEDEDF2, DIM = 0xFF8A8A96;
    static Module.Category selected = Module.Category.COMBAT;

    record Hit(int x, int y, int w, int h, IntConsumer click, DoubleConsumer drag) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    final List<Hit> hits = new ArrayList<>();
    Hit dragging; Module expanded; int scroll;

    public ClickGui() { super(Component.literal("Nova")); }

    private static java.lang.reflect.Method TXT; private static boolean txtStr, txtInit;

    /**
     * Draws text. The drawing method is looked up by its shape (Font, String|Component, int, int, int[, boolean]),
     * so a rename like drawString -> text can't break compilation.
     */
    public static void txt(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        Minecraft mc = Minecraft.getInstance();
        try {
            if (!txtInit) {
                txtInit = true;
                for (var m : GuiGraphicsExtractor.class.getMethods()) {
                    Class<?>[] t = m.getParameterTypes();
                    if (!(m.getName().equals("text") || m.getName().equals("drawString"))) continue;
                    if (t.length < 5 || t.length > 6 || t[0] != net.minecraft.client.gui.Font.class) continue;
                    if (!(t[1] == String.class || t[1] == Component.class) || t[2] != int.class || t[3] != int.class || t[4] != int.class) continue;
                    if (t.length == 6 && t[5] != boolean.class) continue;
                    boolean better = TXT == null || (t[1] == String.class && !txtStr) || (t[1] == String.class == txtStr && t.length == 5 && TXT.getParameterCount() == 6);
                    if (better) { TXT = m; txtStr = t[1] == String.class; }
                }
            }
            if (TXT == null) return;
            Object str = txtStr ? s : Component.literal(s);
            Object[] a = TXT.getParameterCount() == 6 ? new Object[]{mc.font, str, x, y, color, true} : new Object[]{mc.font, str, x, y, color};
            TXT.invoke(g, a);
        } catch (Throwable ignored) {}
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mx, int my, float dt) {
        hits.clear();
        g.fill(0, 0, width, height, 0x80000000);
        int W = 380, H = 240, x0 = (width - W) / 2, y0 = (height - H) / 2;
        g.fill(x0, y0, x0 + W, y0 + H, BG);
        g.fill(x0, y0, x0 + 96, y0 + H, SIDE);
        g.fill(x0, y0, x0 + W, y0 + 2, ACCENT);
        txt(g, "NOVA", x0 + 12, y0 + 12, ACCENT);
        txt(g, "singleplayer", x0 + 12, y0 + 24, DIM);

        int cy = y0 + 48;
        for (Module.Category c : Module.Category.values()) {
            boolean sel = c == selected;
            if (sel) { g.fill(x0, cy, x0 + 96, cy + 20, 0xFF1E1A2E); g.fill(x0, cy, x0 + 2, cy + 20, ACCENT); }
            txt(g, c.label, x0 + 14, cy + 6, sel ? ACCENT : DIM);
            hits.add(new Hit(x0, cy, 96, 20, b -> { selected = c; expanded = null; scroll = 0; }, null));
            cy += 22;
        }

        int lx = x0 + 106, lw = W - 116, y = y0 + 10 - scroll, top = y0 + 6, bot = y0 + H - 6;
        for (Module m : Nova.MODULES) {
            if (m.cat != selected) continue;
            y = row(g, m, lx, y, lw, mx, my, top, bot);
        }
        int contentH = y + scroll - (y0 + 10);
        scroll = Math.max(0, Math.min(scroll, contentH - (H - 40)));
        // fixed hint footer
        g.fill(x0 + 96, bot - 2, x0 + W, y0 + H, BG);
        txt(g, "L-click toggle  •  R-click settings  •  scroll", x0 + 106, y0 + H - 12, DIM);
    }

    int row(GuiGraphicsExtractor g, Module m, int x, int y, int w, int mx, int my, int top, int bot) {
        if (y > top - 20 && y < bot - 14) {
            boolean hov = mx >= x && mx < x + w && my >= y && my < y + 22;
            g.fill(x, y, x + w, y + 22, m.enabled ? 0xFF2A2145 : hov ? HOVER : ROW);
            if (m.enabled) g.fill(x, y, x + 2, y + 22, ACCENT);
            txt(g, m.name, x + 10, y + 3, m.enabled ? TEXT : 0xFFBDBDC8);
            txt(g, m.desc, x + 10, y + 13, DIM);
            // toggle pill
            int px = x + w - 30;
            g.fill(px, y + 7, px + 22, y + 15, m.enabled ? ACCENT : 0xFF34343E);
            int kx = m.enabled ? px + 14 : px;
            g.fill(kx, y + 6, kx + 8, y + 16, 0xFFFFFFFF);
            hits.add(new Hit(x, y, w, 22, b -> { if (b == 0) m.toggle(); else if (b == 1 && !m.settings.isEmpty()) expanded = expanded == m ? null : m; }, null));
        }
        y += 24;
        if (expanded == m) {
            for (Setting s : m.settings) {
                if (y > top - 16 && y < bot - 14) {
                    g.fill(x + 8, y, x + w, y + 16, 0xFF18181E);
                    if (s.bool) {
                        txt(g, s.name, x + 16, y + 4, TEXT);
                        g.fill(x + w - 26, y + 4, x + w - 8, y + 12, s.on() ? ACCENT : 0xFF34343E);
                        hits.add(new Hit(x + 8, y, w - 8, 16, b -> s.value = s.on() ? 0 : 1, null));
                    } else {
                        txt(g, s.name + ": " + String.format(s.fmt(), s.value), x + 16, y + 4, TEXT);
                        int sx = x + w - 90, sw = 82;
                        g.fill(sx, y + 7, sx + sw, y + 9, 0xFF34343E);
                        int fill = (int) (sw * (s.value - s.min) / (s.max - s.min));
                        g.fill(sx, y + 7, sx + fill, y + 9, ACCENT);
                        g.fill(sx + fill - 2, y + 4, sx + fill + 2, y + 12, 0xFFFFFFFF);
                        DoubleConsumer set = mxx -> {
                            double f = Math.max(0, Math.min(1, (mxx - sx) / (double) sw));
                            s.value = Math.max(s.min, Math.min(s.max, Math.round((s.min + f * (s.max - s.min)) / s.step) * s.step));
                        };
                        hits.add(new Hit(sx - 4, y, sw + 8, 16, b -> {}, set));
                    }
                }
                y += 18;
            }
        }
        return y;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent e, boolean dbl) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.in(e.x(), e.y())) {
                h.click().accept(e.button());
                if (h.drag() != null) { dragging = h; h.drag().accept(e.x()); }
                return true;
            }
        }
        return super.mouseClicked(e, dbl);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent e, double dx, double dy) {
        if (dragging != null) { dragging.drag().accept(e.x()); return true; }
        return super.mouseDragged(e, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent e) { dragging = null; return super.mouseReleased(e); }

    @Override
    public boolean mouseScrolled(double x, double y, double sx, double sy) {
        scroll = Math.max(0, scroll - (int) (sy * 14)); return true;
    }
}
