package dev.nova;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import java.util.List;

public class CrystalModules {
    public static List<Module> all() {
        return List.of(new AutoHitCrystal(), new AnchorAura(), new SafeAnchor(), new AutoBase(), new AutoTrap(), new AutoWeb(),
            new SelfTrap(), new HoverTotem(), new Offhand(), new AutoArmor(), new AutoXP(), new AutoGap(), new PvPInfo());
    }

    /** Instantly breaks any end crystal under your crosshair. */
    public static class AutoHitCrystal extends Module {
        Setting range = num("Range", 4.5, 2, 6), swing = bool("Swing", true);
        public AutoHitCrystal() { super("AutoHitCrystal", "Breaks crystals the instant you look at them", Category.CRYSTAL); }
        @Override public void onTick() {
            if (mc.crosshairPickEntity instanceof EndCrystal c && mc.player.getEyePosition().distanceTo(c.position()) <= range.get()) {
                mc.gameMode.attack(mc.player, c);
                if (swing.on()) mc.player.swing(InteractionHand.MAIN_HAND);
            }
        }
    }

    /** Overworld anchor bombs: place → charge with glowstone → detonate with a non-fuel item. */
    public static class AnchorAura extends Module {
        Setting range = num("Range", 4.5, 3, 6), targetRange = num("Target Range", 8, 3, 16), maxTargetDist = num("Max Target Dist", 6, 2, 10),
                minSelf = num("Min Self Dist", 3.5, 0, 6), delay = num("Delay", 2, 0, 20), minHealth = num("Min Health", 10, 0, 20),
                charges = num("Charges", 1, 1, 4), place = bool("Place Anchors", true), boom = bool("Detonate", true),
                hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true);
        int cd;
        public AnchorAura() { super("AnchorAura", "Place, charge and blow up respawn anchors (glowstone in hotbar)", Category.CRYSTAL); noDelay(); }
        @Override public void onTick() {
            var p = mc.player; var lvl = mc.level; var inv = p.getInventory();
            if (++cd < delay.i() || p.getHealth() <= minHealth.get()) return;
            LivingEntity t = Util.target(targetRange.get(), hostile.on(), stands.on(), false); if (t == null) return;
            int r = (int) Math.ceil(range.get());
            BlockPos c = p.blockPosition(), anchor = null; double bd = 1e9;
            for (BlockPos pos : BlockPos.betweenClosed(c.offset(-r, -3, -r), c.offset(r, 3, r))) {
                if (!lvl.getBlockState(pos).is(Blocks.RESPAWN_ANCHOR)) continue;
                Vec3 ctr = Vec3.atCenterOf(pos);
                if (p.getEyePosition().distanceTo(ctr) > range.get() || ctr.distanceTo(p.position()) < minSelf.get()) continue;
                double d = ctr.distanceTo(t.position());
                if (d < bd && d <= maxTargetDist.get()) { bd = d; anchor = pos.immutable(); }
            }
            if (anchor != null) {
                int charge = lvl.getBlockState(anchor).getValue(RespawnAnchorBlock.CHARGE), old = inv.getSelectedSlot(), slot;
                if (charge < charges.i()) { slot = Util.hotbar(Items.GLOWSTONE); if (slot < 0) return; }
                else {
                    if (!boom.on()) return;
                    slot = old; for (int i = 0; i < 9; i++) if (!inv.getItem(i).is(Items.GLOWSTONE)) { slot = i; break; }
                }
                inv.setSelectedSlot(slot);
                mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(anchor), Direction.UP, anchor, false));
                p.swing(InteractionHand.MAIN_HAND); inv.setSelectedSlot(old); cd = 0; return;
            }
            if (!place.on()) return;
            BlockPos f = t.blockPosition();
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                BlockPos pos = f.offset(dx, 0, dz);
                if (Vec3.atCenterOf(pos).distanceTo(p.position()) < minSelf.get()) continue;
                if (Util.place(pos, Items.RESPAWN_ANCHOR, true)) { cd = 0; return; }
            }
        }
    }

    /**
     * Place a respawn anchor by hand and Nova does the rest:
     * charge → glowstone shield on the side facing you → detonate (clicks the top face).
     */
    public static class SafeAnchor extends Module {
        Setting delay = num("Delay", 1, 0, 10), minDist = num("Min Distance", 2.5, 0, 6), charges = num("Charges", 1, 1, 4),
                shield = bool("Glowstone Shield", true), shieldTop = bool("Shield Top Too", false), boom = bool("Auto Detonate", true),
                reach = num("Reach", 5.5, 3, 6), retries = num("Shield Retries", 5, 0, 20), timeout = num("Timeout (ticks)", 60, 20, 200);
        BlockPos pending, anchor; int stage, cd, age, pendAge, fails;

        public SafeAnchor() { super("SafeAnchor", "Place an anchor → auto charge, shield with glowstone, detonate", Category.CRYSTAL); noDelay(); }
        @Override public void onDisable() { reset(); pending = null; }

        void reset() { anchor = null; stage = 0; cd = 0; age = 0; fails = 0; }
        void abort(String why) { Nova.msg("SafeAnchor: " + why); reset(); }

        void use(int slot, BlockPos pos) {
            var p = mc.player; var inv = p.getInventory(); int old = inv.getSelectedSlot();
            inv.setSelectedSlot(slot);
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                new BlockHitResult(Vec3.atCenterOf(pos).add(0, 0.5, 0), Direction.UP, pos, false));
            p.swing(InteractionHand.MAIN_HAND);
            inv.setSelectedSlot(old);
        }

        @Override public void onTick() {
            var p = mc.player; var lvl = mc.level;
            if (anchor == null) {                                                // watch for you placing an anchor
                if (pending != null) {
                    if (lvl.getBlockState(pending).is(Blocks.RESPAWN_ANCHOR)) { anchor = pending; pending = null; stage = 0; cd = 0; age = 0; fails = 0; return; }
                    if (++pendAge > 6) pending = null;
                }
                if (p.getMainHandItem().is(Items.RESPAWN_ANCHOR) && mc.options.keyUse.isDown()
                    && mc.hitResult instanceof BlockHitResult h && h.getType() == HitResult.Type.BLOCK) {
                    BlockPos cand = h.getBlockPos().relative(h.getDirection());
                    if (!lvl.getBlockState(cand).is(Blocks.RESPAWN_ANCHOR)) { pending = cand; pendAge = 0; }
                }
                return;
            }
            if (++age > timeout.i()) { abort("timed out"); return; }
            var state = lvl.getBlockState(anchor);
            if (!state.is(Blocks.RESPAWN_ANCHOR)) { reset(); return; }          // exploded / broken
            if (++cd < delay.i()) return; cd = 0;
            Vec3 c = Vec3.atCenterOf(anchor);
            if (p.getEyePosition().distanceTo(c) > reach.get()) { abort("anchor out of reach"); return; }

            if (stage == 0) {                                                    // 1) charge
                if (state.getValue(RespawnAnchorBlock.CHARGE) >= charges.i()) { stage = 1; return; }
                int g = Util.hotbar(Items.GLOWSTONE);
                if (g < 0) { abort("no glowstone in hotbar"); return; }
                use(g, anchor);
            } else if (stage == 1) {                                             // 2) shield
                if (!shield.on()) { stage = 2; return; }
                Vec3 d = p.position().subtract(c);
                Direction dir = Math.abs(d.x) > Math.abs(d.z) ? (d.x > 0 ? Direction.EAST : Direction.WEST)
                                                              : (d.z > 0 ? Direction.SOUTH : Direction.NORTH);
                List<BlockPos> spots = shieldTop.on() ? List.of(anchor.relative(dir), anchor.above()) : List.of(anchor.relative(dir));
                boolean waiting = false;
                for (BlockPos q : spots) {
                    if (!lvl.getBlockState(q).canBeReplaced()) continue;
                    waiting = true;
                    if (!Util.place(q, Items.GLOWSTONE, true)) fails++;
                    break;
                }
                if (!waiting || fails > retries.i()) stage = 2;
            } else {                                                             // 3) detonate
                if (!boom.on()) { reset(); return; }
                if (c.distanceTo(p.position()) < minDist.get()) { abort("too close to detonate"); return; }
                if (p.getOffhandItem().is(Items.GLOWSTONE)) { abort("glowstone in offhand blocks detonation"); return; }
                var inv = p.getInventory(); int slot = inv.getSelectedSlot();
                if (inv.getItem(slot).is(Items.GLOWSTONE))
                    for (int i = 0; i < 9; i++) if (!inv.getItem(i).is(Items.GLOWSTONE)) { slot = i; break; }
                use(slot, anchor);
            }
        }
    }

    /** Builds obsidian bases around the target so AutoCrystal always has somewhere to place. */
    public static class AutoBase extends Module {
        Setting bases = num("Bases Wanted", 2, 1, 6), radius = num("Place Radius", 2, 2, 4), targetRange = num("Target Range", 7, 3, 16),
                hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true);
        public AutoBase() { super("AutoBase", "Places obsidian bases around the target", Category.CRYSTAL); }
        @Override public void onTick() {
            LivingEntity t = Util.target(targetRange.get(), hostile.on(), stands.on(), false); if (t == null) return;
            BlockPos f = t.blockPosition(); int have = 0, R = radius.i();
            for (BlockPos pos : BlockPos.betweenClosed(f.offset(-R - 1, -1, -R - 1), f.offset(R + 1, 1, R + 1))) {
                var st = mc.level.getBlockState(pos);
                if ((st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK)) && mc.level.getBlockState(pos.above()).isAir()
                    && mc.level.getBlockState(pos.above(2)).isAir()) have++;
            }
            if (have >= bases.i()) return;
            for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
                if (Math.max(Math.abs(dx), Math.abs(dz)) != R) continue;
                BlockPos pos = f.offset(dx, 0, dz);
                if (mc.level.getBlockState(pos.below()).isAir() || !mc.level.getBlockState(pos.above()).isAir()) continue;
                if (Util.place(pos, Items.OBSIDIAN, true)) return;
            }
        }
    }

    /** Boxes the target in obsidian: feet ring → head ring → lid. */
    public static class AutoTrap extends Module {
        Setting range = num("Range", 5, 3, 6), perTick = num("Blocks/Tick", 2, 1, 6), feet = bool("Feet Ring", true),
                head = bool("Head Ring", true), top = bool("Cover Top", true), hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true);
        public AutoTrap() { super("AutoTrap", "Traps the target in obsidian", Category.CRYSTAL); }
        @Override public void onTick() {
            LivingEntity t = Util.target(range.get(), hostile.on(), stands.on(), false); if (t == null) return;
            BlockPos f = t.blockPosition(); int placed = 0;
            for (int layer = 0; layer < 2; layer++) {
                if ((layer == 0 && !feet.on()) || (layer == 1 && !head.on())) continue;
                for (Direction d : Direction.Plane.HORIZONTAL) {
                    if (placed >= perTick.i()) return;
                    if (Util.place(f.relative(d).above(layer), Items.OBSIDIAN, true)) placed++;
                }
            }
            if (top.on() && placed < perTick.i()) Util.place(f.above(2), Items.OBSIDIAN, true);
        }
    }

    /** Drops cobwebs on the target. */
    public static class AutoWeb extends Module {
        Setting range = num("Range", 5, 3, 6), head = bool("Head Too", true), hostile = bool("Hostile Only", false), stands = bool("Armor Stands", true);
        public AutoWeb() { super("AutoWeb", "Places cobwebs on the target", Category.CRYSTAL); }
        @Override public void onTick() {
            LivingEntity t = Util.target(range.get(), hostile.on(), stands.on(), false); if (t == null) return;
            if (!Util.place(t.blockPosition(), Items.COBWEB, false) && head.on()) Util.place(t.blockPosition().above(), Items.COBWEB, false);
        }
    }

    /** Covers your own head so crystals can't hit you from above. */
    public static class SelfTrap extends Module {
        Setting perTick = num("Blocks/Tick", 1, 1, 5), sides = bool("Head Sides", true), top = bool("Cover Top", true);
        public SelfTrap() { super("SelfTrap", "Obsidian over your head + sides", Category.CRYSTAL); }
        @Override public void onTick() {
            BlockPos f = mc.player.blockPosition(); int placed = 0;
            if (sides.on()) for (Direction d : Direction.Plane.HORIZONTAL) {
                if (placed >= perTick.i()) return;
                if (Util.place(f.relative(d).above(), Items.OBSIDIAN, true)) placed++;
            }
            if (top.on() && placed < perTick.i()) Util.place(f.above(2), Items.OBSIDIAN, true);
        }
    }

    /** Open your inventory and just hover: totem → offhand, then totems → empty hotbar slots. */
    public static class HoverTotem extends Module {
        Setting delay = num("Delay", 1, 0, 20), offhand = bool("Offhand First", true), refill = bool("Refill Hotbar", true),
                pull = bool("Pull Into Empty Slot", true);
        int cd;
        public HoverTotem() { super("HoverTotem", "Hover a totem in your inventory to equip / refill", Category.CRYSTAL); noDelay(); }
        @Override public boolean tickInScreen() { return true; }
        void clicked(int id, int slot, int button) {
            cd = 0;
            if (!Util.swapClick(id, slot, button)) { Nova.msg("HoverTotem: inventory click API not found in this version"); setEnabled(false); }
        }
        int emptyHotbar() {
            for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).isEmpty()) return i;
            return -1;
        }
        @Override public void onTick() {
            if (!(mc.screen instanceof AbstractContainerScreen<?> scr) || !(scr.getMenu() instanceof InventoryMenu menu)) return;
            if (++cd < delay.i()) return;
            var slot = Util.hovered(scr); if (slot == null) return;
            int id = menu.containerId, idx = slot.index;     // 9-35 main, 36-44 hotbar, 45 offhand
            var p = mc.player;
            if (slot.getItem().is(Items.TOTEM_OF_UNDYING)) {
                if (idx == 45) return;
                if (offhand.on() && !p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) { clicked(id, idx, 40); return; }
                if (refill.on() && idx >= 9 && idx <= 35) {
                    int e = emptyHotbar();
                    if (e >= 0) clicked(id, idx, e);
                }
            } else if (pull.on() && slot.getItem().isEmpty() && idx >= 36 && idx <= 44) {
                for (int i = 9; i <= 35; i++)
                    if (menu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) { clicked(id, i, idx - 36); break; }
            }
        }
    }

    /** Smart offhand: totem when low, crystal (or gapple) otherwise. */
    public static class Offhand extends Module {
        Setting totemHp = num("Totem Below HP", 10, 2, 20), absorb = bool("Count Absorption", true), crystalDefault = bool("Crystal Default", true);
        public Offhand() { super("Offhand", "Crystal in offhand, totem when you're low", Category.CRYSTAL); }
        @Override public void onTick() {
            var p = mc.player;
            boolean low = p.getHealth() + (absorb.on() ? p.getAbsorptionAmount() : 0) <= totemHp.get();
            Item def = crystalDefault.on() ? Items.END_CRYSTAL : Items.GOLDEN_APPLE;
            if (!Util.offhandSwap(low ? Items.TOTEM_OF_UNDYING : def) && !low) Util.offhandSwap(Items.TOTEM_OF_UNDYING);
        }
    }

    /** Equips armor from your hotbar when a slot is empty. */
    public static class AutoArmor extends Module {
        Setting delay = num("Delay", 3, 0, 20), safeOnly = bool("Only If No Target Near", false), safeRange = num("Safe Range", 6, 2, 16);
        int cd;
        public AutoArmor() { super("AutoArmor", "Re-equips armor from the hotbar", Category.CRYSTAL); noDelay(); }
        @Override public void onTick() {
            if (++cd < delay.i()) return;
            if (safeOnly.on() && Util.target(safeRange.get()) != null) return;
            var p = mc.player; var inv = p.getInventory();
            for (int i = 0; i < 9; i++) {
                ItemStack st = inv.getItem(i); if (st.isEmpty()) continue;
                EquipmentSlot es = p.getEquipmentSlotForItem(st);
                if (es != EquipmentSlot.HEAD && es != EquipmentSlot.CHEST && es != EquipmentSlot.LEGS && es != EquipmentSlot.FEET) continue;
                if (!p.getItemBySlot(es).isEmpty()) continue;
                int old = inv.getSelectedSlot(); inv.setSelectedSlot(i);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                inv.setSelectedSlot(old); cd = 0; return;
            }
        }
    }

    /** Throws XP bottles to mend armor. */
    public static class AutoXP extends Module {
        Setting below = num("Repair Below %", 90, 10, 100), delay = num("Delay", 3, 0, 20), lookDown = bool("Look Down", true),
                noTarget = bool("Only If No Target Near", false), safeRange = num("Safe Range", 8, 2, 16), bottles = num("Bottles/Throw", 1, 1, 3);
        int cd;
        public AutoXP() { super("AutoXP", "Mends damaged armor with XP bottles", Category.CRYSTAL); noDelay(); }
        @Override public void onTick() {
            if (++cd < delay.i()) return;
            var p = mc.player; int s = Util.hotbar(Items.EXPERIENCE_BOTTLE); if (s < 0) return;
            if (noTarget.on() && Util.target(safeRange.get()) != null) return;
            boolean need = false;
            for (EquipmentSlot es : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                ItemStack st = p.getItemBySlot(es);
                if (st.isDamaged() && (st.getMaxDamage() - st.getDamageValue()) * 100.0 / st.getMaxDamage() < below.get()) need = true;
            }
            if (!need) return;
            var inv = p.getInventory(); int old = inv.getSelectedSlot();
            if (lookDown.on()) p.setXRot(90);
            inv.setSelectedSlot(s);
            for (int i = 0; i < bottles.i(); i++) mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            inv.setSelectedSlot(old); cd = 0;
        }
    }

    /** Eats a golden apple when you're low. */
    public static class AutoGap extends Module {
        Setting hp = num("Eat Below HP", 10, 2, 20), minAbs = num("Min Absorption", 2, 0, 16), enchFirst = bool("Prefer Enchanted", true),
                timeout = num("Eat Timeout (ticks)", 60, 20, 120), restore = bool("Restore Slot", true);
        boolean eating; int old, t;
        public AutoGap() { super("AutoGap", "Eats a golden apple when low on health", Category.CRYSTAL); noDelay(); }
        int slot() {
            int e = Util.hotbar(Items.ENCHANTED_GOLDEN_APPLE), g = Util.hotbar(Items.GOLDEN_APPLE);
            return enchFirst.on() ? (e >= 0 ? e : g) : (g >= 0 ? g : e);
        }
        @Override public void onTick() {
            var p = mc.player; var inv = p.getInventory();
            boolean need = p.getHealth() <= hp.get() && p.getAbsorptionAmount() < minAbs.get();
            if (!eating && need && slot() >= 0) {
                old = inv.getSelectedSlot(); inv.setSelectedSlot(slot()); mc.options.keyUse.setDown(true); eating = true; t = 0;
            } else if (eating && (++t > timeout.i() || (!need && !p.isUsingItem()))) stop();
        }
        void stop() {
            mc.options.keyUse.setDown(false);
            if (restore.on() && mc.player != null) mc.player.getInventory().setSelectedSlot(old);
            eating = false;
        }
        @Override public void onDisable() { if (eating) stop(); }
    }

    /** On-screen crystal-PvP info panel. */
    public static class PvPInfo extends Module {
        public static PvPInfo INSTANCE;
        Setting crystals = bool("Show Crystals", true), totems = bool("Show Totems", true), obsidian = bool("Show Obsidian", true),
                target = bool("Show Target", true), posX = num("Pos X", 8, 0, 400), posY = num("Pos Y %", 40, 0, 90);
        public PvPInfo() { super("PvPInfo", "Crystal/totem/obsidian counts + target health", Category.RENDER); noDelay(); spOnly = false; INSTANCE = this; }
        public static void draw(GuiGraphicsExtractor g) {
            PvPInfo s = INSTANCE; Minecraft mc = Minecraft.getInstance(); if (mc.player == null) return;
            LivingEntity t = s.target.on() ? Util.target(10) : null;
            int x = s.posX.i(), y = (int) (mc.getWindow().getGuiScaledHeight() * s.posY.get() / 100.0), lines = 0;
            int rows = (s.crystals.on() ? 1 : 0) + (s.totems.on() ? 1 : 0) + (s.obsidian.on() ? 1 : 0);
            int h = rows * 11 + (t != null ? 26 : 0) + 4;
            if (rows == 0 && t == null) return;
            g.fill(x - 4, y - 4, x + 110, y + h, 0x90101014);
            g.fill(x - 4, y - 4, x - 2, y + h, 0xFFB388FF);
            if (s.crystals.on()) ClickGui.txt(g, "Crystals  " + Util.count(Items.END_CRYSTAL), x, y + 11 * lines++, 0xFFFFFFFF);
            if (s.totems.on()) ClickGui.txt(g, "Totems    " + Util.count(Items.TOTEM_OF_UNDYING), x, y + 11 * lines++, 0xFFFFD166);
            if (s.obsidian.on()) ClickGui.txt(g, "Obsidian  " + Util.count(Items.OBSIDIAN), x, y + 11 * lines++, 0xFFB388FF);
            if (t != null) {
                int ty = y + 11 * lines + 2;
                ClickGui.txt(g, t.getName().getString(), x, ty, 0xFFFFFFFF);
                float f = Math.max(0, Math.min(1, t.getHealth() / t.getMaxHealth()));
                g.fill(x, ty + 12, x + 100, ty + 16, 0xFF34343E);
                g.fill(x, ty + 12, x + (int) (100 * f), ty + 16, f > 0.5f ? 0xFF57E389 : f > 0.25f ? 0xFFFFD166 : 0xFFFF5F5F);
            }
        }
    }
}
