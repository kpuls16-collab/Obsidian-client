package dev.nova;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class Util {
    static Minecraft mc() { return Minecraft.getInstance(); }

    public static boolean valid(LivingEntity le, boolean hostileOnly, boolean stands) {
        if (le == mc().player || !le.isAlive() || le.isSpectator()) return false;
        if (hostileOnly && !(le instanceof Enemy)) return false;
        if (!stands && le instanceof ArmorStand) return false;
        return true;
    }

    public static LivingEntity target(double range) { return target(range, false, true, false); }

    /** Best living target in range. In singleplayer that's mobs / armor stands / dummies. */
    public static LivingEntity target(double range, boolean hostileOnly, boolean stands, boolean lowestHp) {
        var p = mc().player; if (p == null || mc().level == null) return null;
        LivingEntity best = null; double bs = Double.MAX_VALUE;
        for (Entity e : mc().level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || !valid(le, hostileOnly, stands)) continue;
            double d = p.distanceTo(le);
            if (d > range) continue;
            double score = lowestHp ? le.getHealth() + d * 0.01 : d;
            if (score < bs) { bs = score; best = le; }
        }
        return best;
    }

    public static int hotbar(Item item) {
        var inv = mc().player.getInventory();
        for (int i = 0; i < 9; i++) if (inv.getItem(i).is(item)) return i;
        return -1;
    }

    public static float[] aimAt(Vec3 t) {
        Vec3 eye = mc().player.getEyePosition();
        double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z, h = Math.sqrt(dx * dx + dz * dz);
        return new float[]{(float) (Math.toDegrees(Math.atan2(dz, dx)) - 90), (float) -Math.toDegrees(Math.atan2(dy, h))};
    }
    public static float[] aim(Entity e) { return aimAt(e.getBoundingBox().getCenter()); }

    /** turn toward {yaw,pitch}; speed 1 = snap, lower = smoother */
    public static void rotate(float[] a, double speed) {
        var p = mc().player;
        p.setYRot(p.getYRot() + Mth.wrapDegrees(a[0] - p.getYRot()) * (float) speed);
        p.setXRot(p.getXRot() + Mth.wrapDegrees(a[1] - p.getXRot()) * (float) speed);
    }

    /** Place a block at pos by clicking an adjacent solid face. Returns true if a click was sent. */
    public static boolean place(BlockPos pos, Item item, boolean checkEntities) {
        var p = mc().player; var lvl = mc().level;
        if (!lvl.getBlockState(pos).canBeReplaced()) return false;
        if (p.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > 4.6) return false;
        if (checkEntities && !lvl.getEntities((Entity) null, new AABB(pos), e -> !e.isSpectator()).isEmpty()) return false;
        int s = hotbar(item); if (s < 0) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            var st = lvl.getBlockState(n);
            if (st.isAir() || st.canBeReplaced()) continue;
            Vec3 hit = Vec3.atCenterOf(n).add(-d.getStepX() * 0.5, -d.getStepY() * 0.5, -d.getStepZ() * 0.5);
            var inv = p.getInventory(); int old = inv.getSelectedSlot();
            inv.setSelectedSlot(s);
            mc().gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(hit, d.getOpposite(), n, false));
            p.swing(InteractionHand.MAIN_HAND);
            inv.setSelectedSlot(old);
            return true;
        }
        return false;
    }

    private static long lastSwap = -100;

    /** Swap the given hotbar item into the offhand. Syncs the hotbar slot to the server first. */
    public static boolean offhandSwap(Item item) {
        var p = mc().player;
        if (p.getOffhandItem().is(item)) return true;
        int s = hotbar(item); if (s < 0) return false;
        long now = mc().level.getGameTime();
        if (now - lastSwap < 3) return true;                       // wait for the server to confirm the last swap
        lastSwap = now;
        int old = p.getInventory().getSelectedSlot();
        var conn = mc().getConnection();
        conn.send(new net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket(s));
        conn.send(new net.minecraft.network.protocol.game.ServerboundPlayerActionPacket(
            net.minecraft.network.protocol.game.ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND,
            BlockPos.ZERO, Direction.DOWN));
        conn.send(new net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket(old));
        return true;
    }

    public static int count(Item item) {
        var p = mc().player; int n = 0;
        for (int i = 0; i < 36; i++) { var st = p.getInventory().getItem(i); if (st.is(item)) n += st.getCount(); }
        if (p.getOffhandItem().is(item)) n += p.getOffhandItem().getCount();
        return n;
    }

    // ── version-proof helpers (looked up by shape, so a mapping rename can't break the build) ──
    private static java.lang.reflect.Method CLK, HOV_M; private static java.lang.reflect.Field HOV_F;
    private static Object SWAP; private static boolean clkInit, hovInit;

    /** Inventory SWAP click: button 0-8 = hotbar slot, 40 = offhand. Returns false if the API couldn't be found. */
    public static boolean swapClick(int container, int slot, int button) {
        try {
            if (!clkInit) {
                clkInit = true;
                for (var m : net.minecraft.client.multiplayer.MultiPlayerGameMode.class.getMethods()) {
                    Class<?>[] t = m.getParameterTypes();
                    if (t.length == 5 && t[0] == int.class && t[1] == int.class && t[2] == int.class && t[3].isEnum()
                        && t[4] == net.minecraft.world.entity.player.Player.class) {
                        for (Object c : t[3].getEnumConstants()) if (((Enum<?>) c).name().equals("SWAP")) { CLK = m; SWAP = c; }
                        if (CLK != null) break;
                    }
                }
            }
            if (CLK == null) return false;
            CLK.invoke(mc().gameMode, container, slot, button, SWAP, mc().player);
            return true;
        } catch (Throwable t) { return false; }
    }

    /** The slot the mouse is over in a container screen (public getter if present, else the protected field). */
    public static net.minecraft.world.inventory.Slot hovered(net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> s) {
        try {
            if (!hovInit) {
                hovInit = true;
                try { HOV_M = net.minecraft.client.gui.screens.inventory.AbstractContainerScreen.class.getMethod("getSlotUnderMouse"); } catch (Throwable ignored) {}
                if (HOV_M == null) {
                    try {
                        HOV_F = net.minecraft.client.gui.screens.inventory.AbstractContainerScreen.class.getDeclaredField("hoveredSlot");
                        HOV_F.setAccessible(true);
                    } catch (Throwable ignored) {}
                }
            }
            if (HOV_M != null) return (net.minecraft.world.inventory.Slot) HOV_M.invoke(s);
            if (HOV_F != null) return (net.minecraft.world.inventory.Slot) HOV_F.get(s);
        } catch (Throwable ignored) {}
        return null;
    }
}
