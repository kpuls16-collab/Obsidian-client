package dev.nova;

public class Setting {
    public final String name;
    public double value;
    public final double min, max, step;
    public final boolean bool;

    public Setting(String name, double value, double min, double max) {
        this(name, value, min, max, (isInt(value) && isInt(min) && isInt(max)) || (max - min) >= 10 ? 1 : 0.1);
    }
    public Setting(String name, double value, double min, double max, double step) {
        this.name = name; this.value = value; this.min = min; this.max = max; this.step = step; this.bool = false;
    }
    public Setting(String name, boolean value) {
        this.name = name; this.value = value ? 1 : 0; this.min = 0; this.max = 1; this.step = 1; this.bool = true;
    }
    private static boolean isInt(double d) { return d == Math.rint(d); }
    public boolean on() { return value > 0.5; }
    public double get() { return value; }
    public int i() { return (int) Math.round(value); }
    public String fmt() { return step >= 1 ? "%.0f" : step >= 0.1 ? "%.1f" : "%.2f"; }
}
